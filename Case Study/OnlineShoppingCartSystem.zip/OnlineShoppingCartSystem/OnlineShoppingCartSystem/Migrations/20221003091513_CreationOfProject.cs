﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OnlineShoppingCartSystem.Migrations
{
    public partial class CreationOfProject : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
